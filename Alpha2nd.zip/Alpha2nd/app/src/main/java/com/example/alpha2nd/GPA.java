package com.example.alpha2nd;



import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class GPA extends AppCompatActivity {

    //Variables
    TextView display;
    private TextView mark1, mark2, mark3, mark4, mark5, mark6, mark7, mark8, mark9;
    private TextView mark10, mark11, mark12, mark13, mark14, mark15;
    private TextView grade1, grade2, grade3, grade4, grade5, grade6, grade7, grade8, grade9, grade10, grade11, grade12, grade13, grade14, grade15;
    private Spinner sp1, sp2, sp3, sp4, sp5, sp6, sp7, sp8, sp9, sp10, sp11, sp12, sp13, sp14, sp15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpa);
        setSpinners();

        //Initializing text views
        display = (TextView) findViewById(R.id.dis);

        mark1 = (TextView) findViewById(R.id.mark1);
        mark2 = (TextView) findViewById(R.id.mark2);
        mark3 = (TextView) findViewById(R.id.mark3);
        mark4 = (TextView) findViewById(R.id.mark4);
        mark5 = (TextView) findViewById(R.id.mark5);
        mark6 = (TextView) findViewById(R.id.mark6);
        mark7 = (TextView) findViewById(R.id.mark7);
        mark8 = (TextView) findViewById(R.id.mark8);
        mark9 = (TextView) findViewById(R.id.mark9);
        mark10 = (TextView) findViewById(R.id.mark10);
        mark11 = (TextView) findViewById(R.id.mark11);
        mark12 = (TextView) findViewById(R.id.mark12);
        mark13 = (TextView) findViewById(R.id.mark13);
        mark14 = (TextView) findViewById(R.id.mark14);
        mark15 = (TextView) findViewById(R.id.mark15);

        grade1 = (TextView) findViewById(R.id.grade1);
        grade2 = (TextView) findViewById(R.id.grade2);
        grade3 = (TextView) findViewById(R.id.grade3);
        grade4 = (TextView) findViewById(R.id.grade4);
        grade5 = (TextView) findViewById(R.id.grade5);
        grade6 = (TextView) findViewById(R.id.grade6);
        grade7 = (TextView) findViewById(R.id.grade7);
        grade8 = (TextView) findViewById(R.id.grade8);
        grade9 = (TextView) findViewById(R.id.grade9);
        grade10 = (TextView) findViewById(R.id.grade10);
        grade11 = (TextView) findViewById(R.id.grade11);
        grade12 = (TextView) findViewById(R.id.grade12);
        grade13 = (TextView) findViewById(R.id.grade13);
        grade14 = (TextView) findViewById(R.id.grade14);
        grade15 = (TextView) findViewById(R.id.grade15);

        mark1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark7.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark8.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark9.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark10.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark11.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark12.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark13.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark14.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        mark15.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateGPA();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private String marks[] = new String[15];
    private void updateGPA() {

        String enteredMark;

        //Collecting inputs
        enteredMark = mark1.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[0] = enteredMark;
        }  else marks[0] = "-1";
        enteredMark = mark2.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[1] = enteredMark;
        }  else marks[1] = "-1";
        enteredMark = mark3.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[2] = enteredMark;
        }  else marks[2] = "-1";
        enteredMark = mark4.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[3] = enteredMark;
        }  else marks[3] = "-1";
        enteredMark = mark5.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[4] = enteredMark;
        }  else marks[4] = "-1";
        enteredMark = mark6.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[5] = enteredMark;
        }  else marks[5] = "-1";
        enteredMark = mark7.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[6] = enteredMark;
        }  else marks[6] = "-1";
        enteredMark = mark8.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[7] = enteredMark;
        }  else marks[7] = "-1";
        enteredMark = mark9.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[8] = enteredMark;
        }  else marks[8] = "-1";
        enteredMark = mark10.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[9] = enteredMark;
        }  else marks[9] = "-1";
        enteredMark = mark11.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[10] = enteredMark;
        }  else marks[10] = "-1";
        enteredMark = mark12.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[11] = enteredMark;
        }  else marks[11] = "-1";
        enteredMark = mark13.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[12] = enteredMark;
        }  else marks[12] = "-1";
        enteredMark = mark14.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[13] = enteredMark;
        }  else marks[13] = "-1";
        enteredMark = mark15.getText().toString();
        if(enteredMark != null && enteredMark.length()>0){
            marks[14] = enteredMark;
        }  else marks[14] = "-1";
        calculate();
    }
    private void calculate(){
        String val;

        double gpa = 0, totalCredit = 0;
        int subs = 0;
        boolean failed = false;

        double m;
        m = Double.parseDouble(marks[0]);
        if(m!=-1){
            grade1.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp1.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[1]);
        if(m!=-1){
            grade2.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp2.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[2]);
        if(m!=-1){
            grade3.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp3.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[3]);
        if(m!=-1){
            grade4.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp4.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[4]);
        if(m!=-1){
            grade5.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp5.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[5]);
        if(m!=-1){
            grade6.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp6.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[6]);
        if(m!=-1){
            grade7.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp7.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[7]);
        if(m!=-1){
            grade8.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp8.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[8]);
        if(m!=-1){
            grade9.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp9.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[9]);
        if(m!=-1){
            grade10.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp10.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[10]);
        if(m!=-1){
            grade11.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp11.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[11]);
        if(m!=-1){
            grade12.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp12.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[12]);
        if(m!=-1){
            grade13.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp13.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[13]);
        if(m!=-1){
            grade14.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp14.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }
        m = Double.parseDouble(marks[14]);
        if(m!=-1){
            grade15.setText(getGrade(m));
            double credit = Double.parseDouble(String.valueOf(sp15.getSelectedItem()));
            totalCredit += credit;
            gpa += getPoint(m) * credit;
            if(m<40) failed = true;
        }

        if(failed) {
            display.setText("GPA : 0.0 | Grade : F");
        }
        else{
            gpa = gpa / totalCredit;
            String grade = getGrade(gpa * 20);
            display.setText("GPA: "+String.format("%.3f",gpa)+" | Grade: " + grade);
        }
    }
    private String getGrade(double m){
        if(m<40) return "F";
        else if (m<45) return "D";
        else if(m<50) return "C";
        else if(m<55) return "C+";
        else if(m<60) return "B-";
        else if(m<65) return "B";
        else if(m<70) return "B+";
        else if(m<75) return "A-";
        else if(m<80) return "A";
        else if(m<101) return "A+";
        else return "I";
    }

    private double getPoint(double m){
        if(m<40) return 0.0;
        else if (m<45) return 2.00;
        else if(m<50) return 2.25;
        else if(m<55) return 2.50;
        else if(m<60) return 2.75;
        else if(m<65) return 3.00;
        else if(m<70) return 3.25;
        else if(m<75) return 3.50;
        else if(m<80) return 3.75;
        else if(m<101) return 4.00;
        else return -1.0;
    }

    private String op[] = {"3.0", "2.0", "1.5", "1.0"};
    private void setSpinners(){

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, op);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        sp1 = (Spinner) findViewById(R.id.spinner1);
        sp1.setAdapter(aa);

        sp2 = (Spinner) findViewById(R.id.spinner2);
        sp2.setAdapter(aa);

        sp3 = (Spinner) findViewById(R.id.spinner3);
        sp3.setAdapter(aa);

        sp4 = (Spinner) findViewById(R.id.spinner4);
        sp4.setAdapter(aa);

        sp5 = (Spinner) findViewById(R.id.spinner5);
        sp5.setAdapter(aa);

        sp6 = (Spinner) findViewById(R.id.spinner6);
        sp6.setAdapter(aa);

        sp7 = (Spinner) findViewById(R.id.spinner7);
        sp7.setAdapter(aa);

        sp8 = (Spinner) findViewById(R.id.spinner8);
        sp8.setAdapter(aa);

        sp9 = (Spinner) findViewById(R.id.spinner9);
        sp9.setAdapter(aa);

        sp10 = (Spinner) findViewById(R.id.spinner10);
        sp10.setAdapter(aa);

        sp11 = (Spinner) findViewById(R.id.spinner11);
        sp11.setAdapter(aa);

        sp12 = (Spinner) findViewById(R.id.spinner12);
        sp12.setAdapter(aa);

        sp13 = (Spinner) findViewById(R.id.spinner13);
        sp13.setAdapter(aa);

        sp14 = (Spinner) findViewById(R.id.spinner14);
        sp14.setAdapter(aa);

        sp15 = (Spinner) findViewById(R.id.spinner15);
        sp15.setAdapter(aa);
    }
}