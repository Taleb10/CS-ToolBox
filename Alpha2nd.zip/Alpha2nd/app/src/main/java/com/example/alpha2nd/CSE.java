package com.example.alpha2nd;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.ListView;


public class CSE extends AppCompatActivity {

    ListView lvProgram;


    String[] programName = {
            "Introduction To Java Programming",
            "Introduction To C# Programming",
            "Introduction To C++ Programming",
            "Introduction To C Programming",
            "Introduction To Python Programming",
            "Visual Studio A Complete Guide",
            "Operating System",
            "Basic Java",
            "Introduction TO Networking",
            "Advanced Networking",
            "Introduction To Linux",
            "Java 7th Edition",
            "Digital Logic Design 8th Edition",
            "A Complete Guide To Android Studio",
            "Cyber Security & Networking",
            "Machine Learning",
            "Introduction To AI",
            "PHP 13th Edition"
    };

    String[] programDescription = {
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author"

    };
    // Define an integer array to hold the image recourse ids
    int[] programImages = {R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cse);

        lvProgram = findViewById(R.id.lvProgram);

        ProgramAdapter programAdapter = new ProgramAdapter(this, programName, programImages, programDescription);

        lvProgram.setAdapter(programAdapter);



    }

}