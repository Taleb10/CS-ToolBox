package com.example.alpha2nd;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BookList extends AppCompatActivity {

    Button cse,eee,bba,textile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_list);

        //=========

        cse = findViewById(R.id.cseButton);
        eee = findViewById(R.id.eeeButton);
        bba = findViewById(R.id.bbaButton);
        textile = findViewById(R.id.textileButton);

        //if cse button is clicked then this function will show the books avaiable for cse dept.
        cse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookList.this,CSE.class);
                startActivity(intent);
            }
        });

        eee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookList.this,EEE.class);
                startActivity(intent);
            }
        });

        bba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookList.this, BBA.class);
                startActivity(intent);
            }
        });

        textile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookList.this,Textile.class);
                startActivity(intent);
            }
        });




    }
}