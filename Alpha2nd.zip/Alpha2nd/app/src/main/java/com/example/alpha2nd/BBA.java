package com.example.alpha2nd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class BBA extends AppCompatActivity {

    // Create a ListView object reference
    ListView lvProgram;
    // Next, prepare your data set. Create two string arrays for program name and program description respectively.
    String[] programName = {
            "Financial accounting",
            "Business Mathematics",
            "Principles of management",
            "Personality development & communication skill",
            "Computer Fundamentals",
            "Business economic"
    };

    String[] programDescription = {
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author",
            "Author"

    };
    // Define an integer array to hold the image recourse ids
    int[] programImages = {R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library,
            R.drawable.library, R.drawable.library, R.drawable.library};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cse);

        // Get the handle for ListView
        lvProgram = findViewById(R.id.lvProgram);
        // Specify an adapter and pass context along with all the arrays in constructor
        ProgramAdapter programAdapter = new ProgramAdapter(this, programName, programImages, programDescription);
        //ProgramAdapter programAdapter = new ProgramAdapter(this, programName, programImages, programDescription, urls);

        // Set the adapter with the ListView
        lvProgram.setAdapter(programAdapter);
    }
}